import {
  hasDom,
  resolveHost,
  noop,
  bindOnce,
  collectHosts,
  scrollIntoViewSafe,
  closestSafe,
} from './internal.js';

/**
 * @typedef {object} SourceFocusDetail
 * @property {string} id The focused source-card id.
 * @property {Element} citation The citation/control that requested the source.
 * @property {Element} source The target source card or source element.
 */

const REF_SELECTOR = '[data-bronto-source-ref], .ui-citation[href^="#"]';
const ACTIVE = 'is-source-active';

function sourceId(ref) {
  const explicit = ref.getAttribute('data-bronto-source-ref');
  if (explicit) return explicit.replace(/^#/, '');
  const href = ref.getAttribute('href') || '';
  if (!href.startsWith('#') || href === '#') return '';
  try {
    return decodeURIComponent(href.slice(1));
  } catch {
    return href.slice(1);
  }
}

function sourcePreview(source) {
  const text = (selector) =>
    source.querySelector(selector)?.textContent?.replace(/\s+/g, ' ').trim() || '';
  const title = text('.ui-source-card__title');
  const meta = [text('.ui-source-card__origin'), text('.ui-source-card__time')]
    .filter(Boolean)
    .join(' · ');
  const excerpt = text('.ui-source-card__excerpt');
  return [title, meta, excerpt].filter(Boolean).join(' — ');
}

function idMapFor(island) {
  const ids = new Map();
  const add = (el) => {
    if (el?.id && !ids.has(el.id)) ids.set(el.id, el);
  };
  add(island);
  for (const el of island.querySelectorAll?.('[id]') || []) add(el);
  return ids;
}

/**
 * Source/citation affordances for the `sources.css` trust layer. The behavior
 * is deliberately small: within each `[data-bronto-sources]` island it resolves
 * `.ui-citation[href^="#"]` and `[data-bronto-source-ref]` controls to source
 * cards, adds non-visual preview metadata (`title` + `aria-describedby`), and
 * on activation moves focus to the source card with a temporary
 * `.is-source-active` highlight. The host still owns fetching, numbering,
 * trust decisions, and any rich preview UI.
 *
 * @param {import('./internal.js').DelegateOpts} [opts]
 * @returns {import('./internal.js').Cleanup}
 */
export function initSources({ root } = {}) {
  if (!hasDom()) return noop;
  const host = resolveHost(root);
  if (!host) return noop;

  const islands = collectHosts(host, '[data-bronto-sources]');
  const cleanups = [];

  for (const island of islands) {
    const timers = new Set();
    const seeded = [];
    const activeSources = new Set();
    const sourcesById = idMapFor(island);
    const previewBySource = new WeakMap();

    const targetFor = (ref) => {
      const id = sourceId(ref);
      if (!id) return null;
      const source = sourcesById.get(id) || null;
      return source && island.contains(source) ? source : null;
    };

    const previewFor = (source) => {
      let preview = previewBySource.get(source);
      if (preview === undefined) {
        preview = sourcePreview(source);
        previewBySource.set(source, preview);
      }
      return preview;
    };

    const seed = () => {
      for (const ref of island.querySelectorAll(REF_SELECTOR)) {
        const source = targetFor(ref);
        if (!source?.id) continue;

        const describedBy = ref.getAttribute('aria-describedby') || '';
        const describedIds = describedBy.split(/\s+/).filter(Boolean);
        const title = ref.getAttribute('title');
        const preview = previewFor(source);
        const prior = {
          ref,
          describedBy,
          hadDescribedBy: ref.hasAttribute('aria-describedby'),
          title,
          hadTitle: ref.hasAttribute('title'),
        };

        if (!describedIds.includes(source.id)) {
          ref.setAttribute('aria-describedby', [...describedIds, source.id].join(' '));
        }
        if (!title && preview) ref.setAttribute('title', preview);
        if (!source.hasAttribute('tabindex')) {
          prior.source = source;
          prior.hadTabindex = false;
          source.setAttribute('tabindex', '-1');
        }
        seeded.push(prior);
      }
    };

    const clearGeneratedActive = () => {
      for (const source of activeSources) source.classList.remove(ACTIVE);
      activeSources.clear();
    };

    const focusSource = (ref, source) => {
      for (const card of island.querySelectorAll(`.${ACTIVE}`)) card.classList.remove(ACTIVE);
      clearGeneratedActive();
      for (const timer of timers) clearTimeout(timer);
      timers.clear();

      source.classList.add(ACTIVE);
      activeSources.add(source);
      source.focus?.({ preventScroll: true });
      scrollIntoViewSafe(source);

      const timer = setTimeout(() => {
        source.classList.remove(ACTIVE);
        activeSources.delete(source);
        timers.delete(timer);
      }, 1600);
      timers.add(timer);

      island.dispatchEvent(
        new CustomEvent('bronto:source:focus', {
          detail: { id: source.id, citation: ref, source },
          bubbles: true,
        }),
      );
    };

    const onClick = (e) => {
      const ref = closestSafe(e.target, REF_SELECTOR);
      if (!ref || !island.contains(ref)) return;
      const source = targetFor(ref);
      if (!source) return;
      if (!ref.matches('a[href]')) e.preventDefault();
      focusSource(ref, source);
    };

    const cleanup = bindOnce(island, 'sources', () => {
      const activeState = Array.from(island.querySelectorAll(`.${ACTIVE}`));
      seed();
      island.addEventListener('click', onClick);
      return () => {
        island.removeEventListener('click', onClick);
        for (const timer of timers) clearTimeout(timer);
        timers.clear();
        clearGeneratedActive();
        for (const item of seeded.splice(0)) {
          if (item.hadDescribedBy) item.ref.setAttribute('aria-describedby', item.describedBy);
          else item.ref.removeAttribute('aria-describedby');
          if (item.hadTitle) item.ref.setAttribute('title', item.title);
          else item.ref.removeAttribute('title');
          if (item.source && item.hadTabindex === false) item.source.removeAttribute('tabindex');
        }
        for (const source of activeState) source.classList.add(ACTIVE);
      };
    });

    cleanups.push(cleanup);
  }

  return () => cleanups.forEach((fn) => fn());
}
