import { hasDom, resolveHost, noop, bindOnce, byIdInHost } from './internal.js';

/**
 * Wire native <dialog> open/close glue (the one bit <dialog> can't do
 * declaratively). Click `[data-bronto-open="dialogId"]` calls
 * `showModal()` on `#dialogId`; click `[data-bronto-close]` closes the
 * nearest enclosing <dialog>. Clicking the backdrop of a dialog that has
 * `[data-bronto-dialog-light]` closes it too. On open the trigger is
 * remembered and focus is returned to it on *every* close path (Esc,
 * close button, backdrop light-dismiss, programmatic) via the native
 * `close` event, so keyboard/SR users are never dropped at `<body>`.
 * SSR-safe and idempotent; returns cleanup.
 *
 * `root` scopes delegated triggers (default `document`). Controlled targets are
 * resolved root-first, then document-wide, so scoped islands win duplicate-id
 * conflicts without breaking body/portal-mounted overlays.
 *
 * @param {import('./internal.js').DelegateOpts} [opts]
 * @returns {import('./internal.js').Cleanup}
 */
export function initDialog({ root } = {}) {
  if (!hasDom()) return noop;
  const host = resolveHost(root);
  if (!host) return noop;
  const doc = host.nodeType === 9 ? host : host.ownerDocument;
  if (!doc) return noop;
  const managedDialogs = new Set();
  const focusRestorers = new Map();
  const warnedNameless = new WeakSet();
  const canManageDialog = (dlg, origin) => host.contains(origin) || managedDialogs.has(dlg);

  const warnIfNameless = (dlg) => {
    const named =
      dlg.hasAttribute('aria-label') ||
      dlg.hasAttribute('aria-labelledby') ||
      dlg.hasAttribute('title');
    if (named || warnedNameless.has(dlg) || typeof console === 'undefined') return;
    warnedNameless.add(dlg);
    console.warn(
      `[bronto] initDialog(): dialog #${dlg.id || '(without id)'} has no accessible name — add aria-label, aria-labelledby, or title so it is announced as a named dialog.`,
    );
  };

  const openFrom = (opener) => {
    const dlg = byIdInHost(host, opener.getAttribute('data-bronto-open'));
    if (!dlg || typeof dlg.showModal !== 'function' || dlg.open) return false;
    const previous = focusRestorers.get(dlg);
    if (previous) {
      dlg.removeEventListener('close', previous);
      focusRestorers.delete(dlg);
      managedDialogs.delete(dlg);
    }
    const restoreFocus = () => {
      focusRestorers.delete(dlg);
      managedDialogs.delete(dlg);
      if (opener.isConnected && typeof opener.focus === 'function') opener.focus();
    };
    try {
      dlg.showModal();
    } catch {
      return false;
    }
    warnIfNameless(dlg);
    managedDialogs.add(dlg);
    focusRestorers.set(dlg, restoreFocus);
    dlg.addEventListener('close', restoreFocus, { once: true });
    return true;
  };

  const closeFrom = (closer) => {
    const dlg = closer.closest('dialog');
    if (!dlg || !dlg.open || !canManageDialog(dlg, closer)) return false;
    dlg.close();
    return true;
  };

  const lightDismiss = (dlg) => {
    if (
      dlg.tagName === 'DIALOG' &&
      dlg.open &&
      dlg.hasAttribute('data-bronto-dialog-light') &&
      canManageDialog(dlg, dlg)
    ) {
      dlg.close();
      return true;
    }
    return false;
  };

  const onClick = (e) => {
    const target = e.target;
    const opener = target?.closest?.('[data-bronto-open]');
    if (opener && host.contains(opener)) {
      if (openFrom(opener)) e.preventDefault();
      return;
    }
    const closer = target?.closest?.('[data-bronto-close]');
    if (closer) {
      if (closeFrom(closer)) e.preventDefault();
      return;
    }
    // Light-dismiss: a click whose target is the <dialog> itself is the
    // backdrop (content sits in child elements).
    if (lightDismiss(target)) e.preventDefault();
  };
  return bindOnce(host, 'dialog', () => {
    doc.addEventListener('click', onClick);
    return () => {
      doc.removeEventListener('click', onClick);
      for (const [dlg, restoreFocus] of focusRestorers) {
        // Only pull focus back to the opener when it is currently INSIDE this
        // dialog — closing would otherwise strand it on <body>. If the app has
        // already moved focus elsewhere, leave it where it is.
        const focusInside = dlg.contains(doc.activeElement);
        dlg.removeEventListener('close', restoreFocus);
        if (dlg.open) {
          try {
            dlg.close();
          } catch {
            /* already closed */
          }
        }
        if (focusInside) restoreFocus();
      }
      focusRestorers.clear();
      managedDialogs.clear();
    };
  });
}
