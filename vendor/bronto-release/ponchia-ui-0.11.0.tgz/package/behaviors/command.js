import {
  hasDom,
  resolveHost,
  noop,
  bindOnce,
  nextFieldUid,
  collectHosts,
  scrollIntoViewSafe,
  wrapIndex,
  closestSafe,
} from './internal.js';

const localeOf = (el) => {
  const locale =
    closestSafe(el, '[lang]')?.getAttribute('lang')?.trim() ||
    el?.ownerDocument?.documentElement?.getAttribute('lang')?.trim();
  return locale || undefined;
};

const lowerForSearch = (value, locale) => {
  const text = String(value ?? '');
  if (!locale) return text.toLowerCase();
  try {
    return text.toLocaleLowerCase(locale);
  } catch {
    return text.toLowerCase();
  }
};

/**
 * @typedef {object} CommandSelectDetail
 * @property {string} value The chosen command's value.
 * @property {string} label The chosen command's visible label.
 */

/**
 * Command palette — filter + keyboard-navigate a DOM-authored command list.
 * The CSS shell (`.ui-command`) is opt-in; this wires the listbox behavior the
 * shell needs. Bronto filters and navigates; the HOST owns the action registry,
 * permission checks, routing, async effects, and command execution (it listens
 * for `bronto:command:select`). There is no global Cmd/Ctrl+K — open the palette
 * yourself (e.g. a `<dialog>` via `initDialog`).
 *
 * Markup: `[data-bronto-command]` wrapping an `<input>` (`.ui-command__input`)
 * and a list (`.ui-command__list`) of `.ui-command__item` rows (optional
 * `data-value`), interleaved with `.ui-command__group` labels and an optional
 * `.ui-command__empty`. The behavior owns ids, `role=combobox/listbox/option`,
 * `aria-activedescendant`, a roving active item, substring filtering (hiding
 * empty groups), keyboard list navigation (Down/Up/Enter/Escape), and pointer
 * select. It emits `bronto:command:select` ({ detail: { value, label } }) on
 * choose and `bronto:command:close` on Escape. SSR-safe, idempotent per
 * instance; returns a cleanup function.
 *
 * Items are read from the DOM at init; re-run initCommand after replacing the
 * command list so filtering/navigation see the current nodes.
 *
 * @param {import('./internal.js').DelegateOpts} [opts]
 * @returns {import('./internal.js').Cleanup}
 */
export function initCommand({ root } = {}) {
  if (!hasDom()) return noop;
  const host = resolveHost(root);
  if (!host) return noop;
  const palettes = collectHosts(host, '[data-bronto-command]');
  const cleanups = [];

  const snapshotAttrs = (el, names) => {
    const out = {};
    for (const name of names) {
      out[name] = {
        had: el.hasAttribute(name),
        value: el.getAttribute(name),
      };
    }
    return out;
  };

  const restoreAttrs = (el, attrs) => {
    for (const [name, attr] of Object.entries(attrs)) {
      if (attr.had) el.setAttribute(name, attr.value);
      else el.removeAttribute(name);
    }
  };

  const firstTextNode = (el) => {
    for (const node of el.childNodes) {
      if (node.nodeType === 3 && node.nodeValue.trim()) return node;
      if (node.nodeType === 1) {
        const child = firstTextNode(node);
        if (child) return child;
      }
    }
    return null;
  };

  const refreshLiveText = (el) => {
    const node = firstTextNode(el);
    if (!node) return;
    const text = node.nodeValue;
    node.nodeValue = '';
    node.nodeValue = text;
  };

  const prepareEmptyState = (el) => {
    if (!el) return;
    el.setAttribute('role', 'status');
    el.setAttribute('aria-live', 'polite');
  };

  for (const box of palettes) {
    const input = box.querySelector('.ui-command__input, input');
    const list = box.querySelector('.ui-command__list, [role="listbox"]');
    if (!input || !list) continue;
    const empty = box.querySelector('.ui-command__empty');
    const items = [...list.querySelectorAll('.ui-command__item, [role="option"]')];
    const groups = [...list.querySelectorAll('.ui-command__group')];
    const locale = localeOf(box);

    const rememberState = () => ({
      input: snapshotAttrs(input, [
        'role',
        'aria-controls',
        'aria-autocomplete',
        'aria-expanded',
        'aria-activedescendant',
        'autocomplete',
      ]),
      list: snapshotAttrs(list, ['id', 'role']),
      empty: empty
        ? {
            hidden: empty.hidden,
            attrs: snapshotAttrs(empty, ['role', 'aria-live']),
          }
        : null,
      groups: groups.map((g) => ({
        el: g,
        hidden: g.hidden,
        attrs: snapshotAttrs(g, ['role']),
      })),
      items: items.map((it) => ({
        el: it,
        hidden: it.hidden,
        active: it.classList.contains('is-active'),
        attrs: snapshotAttrs(it, ['id', 'role', 'aria-selected']),
      })),
    });

    const restoreState = (state) => {
      restoreAttrs(input, state.input);
      restoreAttrs(list, state.list);
      if (empty && state.empty) {
        empty.hidden = state.empty.hidden;
        restoreAttrs(empty, state.empty.attrs);
      }
      for (const group of state.groups) {
        group.el.hidden = group.hidden;
        restoreAttrs(group.el, group.attrs);
      }
      for (const item of state.items) {
        item.el.hidden = item.hidden;
        item.el.classList.toggle('is-active', item.active);
        restoreAttrs(item.el, item.attrs);
      }
    };

    let active = -1;
    const visible = () => items.filter((it) => !it.hidden);

    const setActive = (item) => {
      items.forEach((it) => {
        it.classList.toggle('is-active', it === item);
        it.setAttribute('aria-selected', String(it === item));
      });
      if (item) {
        active = items.indexOf(item);
        input.setAttribute('aria-activedescendant', item.id);
        scrollIntoViewSafe(item);
      } else {
        active = -1;
        input.removeAttribute('aria-activedescendant');
      }
    };

    // Hide a group whose items are all filtered out.
    const syncGroups = () => {
      for (const g of groups) {
        let any = false;
        for (
          let n = g.nextElementSibling;
          n && !n.matches('.ui-command__group');
          n = n.nextElementSibling
        ) {
          if (n.matches('.ui-command__item, [role="option"]') && !n.hidden) any = true;
        }
        g.hidden = !any;
      }
    };

    const filter = () => {
      const q = lowerForSearch(input.value.trim(), locale);
      let any = false;
      for (const it of items) {
        const match = !q || lowerForSearch(it.textContent, locale).includes(q);
        it.hidden = !match;
        if (match) any = true;
      }
      syncGroups();
      if (empty) {
        empty.hidden = any;
        if (!any) refreshLiveText(empty);
      }
      const vis = visible();
      setActive(vis[0] || null);
    };

    const move = (delta) => {
      const vis = visible();
      if (!vis.length) return;
      setActive(vis[wrapIndex(vis.indexOf(items[active]), delta, vis.length)]);
    };

    const choose = (item) => {
      if (!item || item.hidden) return;
      // Label = the command name only — strip the shortcut/meta hints so the
      // host doesn't get "Open settings G S".
      const clone = item.cloneNode(true);
      clone.querySelectorAll('.ui-command__shortcut, .ui-command__meta').forEach((n) => n.remove());
      const label = clone.textContent.replace(/\s+/g, ' ').trim();
      box.dispatchEvent(
        new CustomEvent('bronto:command:select', {
          detail: { value: item.dataset.value ?? label, label },
          bubbles: true,
        }),
      );
    };

    const onInput = () => filter();
    const onKey = (e) => {
      switch (e.key) {
        case 'ArrowDown':
          e.preventDefault();
          move(1);
          break;
        case 'ArrowUp':
          e.preventDefault();
          move(-1);
          break;
        case 'Enter':
          if (active >= 0 && !items[active].hidden) {
            choose(items[active]);
            e.preventDefault();
          }
          break;
        case 'Escape':
          box.dispatchEvent(new CustomEvent('bronto:command:close', { bubbles: true }));
          break;
        default:
          break;
      }
    };
    const onClick = (e) => {
      const item = closestSafe(e.target, '.ui-command__item, [role="option"]');
      if (item && list.contains(item)) choose(item);
    };

    const bound = bindOnce(box, 'command', () => {
      const state = rememberState();
      const listId = list.id || (list.id = `bronto-cmd-${nextFieldUid()}`);
      const optionIdBase = `bronto-cmd-opt-${nextFieldUid()}`;
      items.forEach((it, i) => {
        if (!it.id) it.id = `${optionIdBase}-${i}`;
        it.setAttribute('role', 'option');
      });
      groups.forEach((g) => g.setAttribute('role', 'presentation'));
      list.setAttribute('role', 'listbox');
      prepareEmptyState(empty);
      input.setAttribute('role', 'combobox');
      input.setAttribute('aria-controls', listId);
      input.setAttribute('aria-autocomplete', 'list');
      input.setAttribute('aria-expanded', 'true');
      input.setAttribute('autocomplete', 'off');
      input.addEventListener('input', onInput);
      input.addEventListener('keydown', onKey);
      list.addEventListener('click', onClick);
      // Seed the initial active item (first visible).
      filter();
      return () => {
        input.removeEventListener('input', onInput);
        input.removeEventListener('keydown', onKey);
        list.removeEventListener('click', onClick);
        restoreState(state);
        active = -1;
      };
    });
    cleanups.push(bound);
  }

  return () => cleanups.forEach((fn) => fn());
}
